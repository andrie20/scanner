namespace CCSRfidScanner {
	partial class Form1 {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.components = new System.ComponentModel.Container();
			this.MainMenu = new System.Windows.Forms.MenuStrip();
			this.ViewSessionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.viewStudentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sessionStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.nothingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.automaticToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.LabelStudentName = new System.Windows.Forms.Label();
			this.LabelTimer = new System.Windows.Forms.Label();
			this.LabelLoginStatus = new System.Windows.Forms.Label();
			this.LabelLogoutStatus = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.ClockTimer = new System.Windows.Forms.Timer(this.components);
			this.label2 = new System.Windows.Forms.Label();
			this.TextBoxRfid = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.LabelStudentCourse = new System.Windows.Forms.Label();
			this.LabelSessionName = new System.Windows.Forms.Label();
			this.LabelSessionNotice = new System.Windows.Forms.Label();
			this.LabelNotFound = new System.Windows.Forms.Label();
			this.LabelAlreadyLoggedIn = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.LabelTotalLogCount = new System.Windows.Forms.Label();
			this.MainMenu.SuspendLayout();
			this.SuspendLayout();
			// 
			// MainMenu
			// 
			this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ViewSessionsToolStripMenuItem,
            this.viewStudentsToolStripMenuItem,
            this.sessionStatusToolStripMenuItem});
			this.MainMenu.Location = new System.Drawing.Point(0, 0);
			this.MainMenu.Name = "MainMenu";
			this.MainMenu.Size = new System.Drawing.Size(872, 24);
			this.MainMenu.TabIndex = 0;
			this.MainMenu.Text = "menuStrip1";
			// 
			// ViewSessionsToolStripMenuItem
			// 
			this.ViewSessionsToolStripMenuItem.Name = "ViewSessionsToolStripMenuItem";
			this.ViewSessionsToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
			this.ViewSessionsToolStripMenuItem.Text = "View Sessions";
			this.ViewSessionsToolStripMenuItem.Click += new System.EventHandler(this.ViewSessionsToolStripMenuItem_Click);
			// 
			// viewStudentsToolStripMenuItem
			// 
			this.viewStudentsToolStripMenuItem.Name = "viewStudentsToolStripMenuItem";
			this.viewStudentsToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
			this.viewStudentsToolStripMenuItem.Text = "View Students";
			this.viewStudentsToolStripMenuItem.Click += new System.EventHandler(this.ViewStudentsToolStripMenuItem_Click);
			// 
			// sessionStatusToolStripMenuItem
			// 
			this.sessionStatusToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.nothingToolStripMenuItem,
            this.toolStripMenuItem1,
            this.automaticToolStripMenuItem});
			this.sessionStatusToolStripMenuItem.Name = "sessionStatusToolStripMenuItem";
			this.sessionStatusToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
			this.sessionStatusToolStripMenuItem.Text = "Session Status";
			// 
			// loginToolStripMenuItem
			// 
			this.loginToolStripMenuItem.BackColor = System.Drawing.Color.White;
			this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
			this.loginToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
			this.loginToolStripMenuItem.Text = "Login";
			this.loginToolStripMenuItem.Click += new System.EventHandler(this.LoginToolStripMenuItem_Click);
			// 
			// logoutToolStripMenuItem
			// 
			this.logoutToolStripMenuItem.BackColor = System.Drawing.Color.White;
			this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
			this.logoutToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
			this.logoutToolStripMenuItem.Text = "Logout";
			this.logoutToolStripMenuItem.Click += new System.EventHandler(this.LogoutToolStripMenuItem_Click);
			// 
			// nothingToolStripMenuItem
			// 
			this.nothingToolStripMenuItem.BackColor = System.Drawing.Color.White;
			this.nothingToolStripMenuItem.Name = "nothingToolStripMenuItem";
			this.nothingToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
			this.nothingToolStripMenuItem.Text = "Not accepting";
			this.nothingToolStripMenuItem.Click += new System.EventHandler(this.NothingToolStripMenuItem_Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(146, 6);
			// 
			// automaticToolStripMenuItem
			// 
			this.automaticToolStripMenuItem.BackColor = System.Drawing.Color.White;
			this.automaticToolStripMenuItem.Checked = true;
			this.automaticToolStripMenuItem.CheckOnClick = true;
			this.automaticToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
			this.automaticToolStripMenuItem.Name = "automaticToolStripMenuItem";
			this.automaticToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
			this.automaticToolStripMenuItem.Text = "Automatic";
			// 
			// LabelStudentName
			// 
			this.LabelStudentName.AutoEllipsis = true;
			this.LabelStudentName.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelStudentName.Location = new System.Drawing.Point(25, 112);
			this.LabelStudentName.Name = "LabelStudentName";
			this.LabelStudentName.Size = new System.Drawing.Size(835, 134);
			this.LabelStudentName.TabIndex = 1;
			// 
			// LabelTimer
			// 
			this.LabelTimer.AutoEllipsis = true;
			this.LabelTimer.Font = new System.Drawing.Font("Segoe UI", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelTimer.Location = new System.Drawing.Point(14, 300);
			this.LabelTimer.Name = "LabelTimer";
			this.LabelTimer.Size = new System.Drawing.Size(846, 115);
			this.LabelTimer.TabIndex = 2;
			this.LabelTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// LabelLoginStatus
			// 
			this.LabelLoginStatus.AutoSize = true;
			this.LabelLoginStatus.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelLoginStatus.ForeColor = System.Drawing.Color.Gray;
			this.LabelLoginStatus.Location = new System.Drawing.Point(364, 414);
			this.LabelLoginStatus.Name = "LabelLoginStatus";
			this.LabelLoginStatus.Size = new System.Drawing.Size(53, 21);
			this.LabelLoginStatus.TabIndex = 5;
			this.LabelLoginStatus.Text = "Login";
			// 
			// LabelLogoutStatus
			// 
			this.LabelLogoutStatus.AutoSize = true;
			this.LabelLogoutStatus.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelLogoutStatus.ForeColor = System.Drawing.Color.Gray;
			this.LabelLogoutStatus.Location = new System.Drawing.Point(444, 414);
			this.LabelLogoutStatus.Name = "LabelLogoutStatus";
			this.LabelLogoutStatus.Size = new System.Drawing.Size(64, 21);
			this.LabelLogoutStatus.TabIndex = 6;
			this.LabelLogoutStatus.Text = "Logout";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.Gray;
			this.label5.Location = new System.Drawing.Point(424, 413);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(15, 21);
			this.label5.TabIndex = 7;
			this.label5.Text = "|";
			// 
			// ClockTimer
			// 
			this.ClockTimer.Interval = 1000;
			this.ClockTimer.Tick += new System.EventHandler(this.ClockTimer_Tick);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(12, 34);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(58, 17);
			this.label2.TabIndex = 8;
			this.label2.Text = "Session:";
			// 
			// TextBoxRfid
			// 
			this.TextBoxRfid.BackColor = System.Drawing.SystemColors.ButtonFace;
			this.TextBoxRfid.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.TextBoxRfid.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.TextBoxRfid.Location = new System.Drawing.Point(92, 65);
			this.TextBoxRfid.Name = "TextBoxRfid";
			this.TextBoxRfid.Size = new System.Drawing.Size(768, 16);
			this.TextBoxRfid.TabIndex = 9;
			this.TextBoxRfid.TextChanged += new System.EventHandler(this.TextBoxRfid_TextChanged);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(14, 62);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(68, 17);
			this.label6.TabIndex = 10;
			this.label6.Text = "Scan here:";
			// 
			// LabelStudentCourse
			// 
			this.LabelStudentCourse.AutoEllipsis = true;
			this.LabelStudentCourse.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelStudentCourse.Location = new System.Drawing.Point(29, 246);
			this.LabelStudentCourse.Name = "LabelStudentCourse";
			this.LabelStudentCourse.Size = new System.Drawing.Size(831, 24);
			this.LabelStudentCourse.TabIndex = 11;
			// 
			// LabelSessionName
			// 
			this.LabelSessionName.AutoEllipsis = true;
			this.LabelSessionName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelSessionName.Location = new System.Drawing.Point(77, 34);
			this.LabelSessionName.Name = "LabelSessionName";
			this.LabelSessionName.Size = new System.Drawing.Size(783, 16);
			this.LabelSessionName.TabIndex = 12;
			// 
			// LabelSessionNotice
			// 
			this.LabelSessionNotice.AutoSize = true;
			this.LabelSessionNotice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelSessionNotice.ForeColor = System.Drawing.Color.Red;
			this.LabelSessionNotice.Location = new System.Drawing.Point(12, 454);
			this.LabelSessionNotice.Name = "LabelSessionNotice";
			this.LabelSessionNotice.Size = new System.Drawing.Size(348, 21);
			this.LabelSessionNotice.TabIndex = 13;
			this.LabelSessionNotice.Text = "NOTE: Login/logout is not allowed anymore.";
			this.LabelSessionNotice.Visible = false;
			// 
			// LabelNotFound
			// 
			this.LabelNotFound.AutoSize = true;
			this.LabelNotFound.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelNotFound.ForeColor = System.Drawing.Color.Red;
			this.LabelNotFound.Location = new System.Drawing.Point(616, 455);
			this.LabelNotFound.Name = "LabelNotFound";
			this.LabelNotFound.Size = new System.Drawing.Size(236, 21);
			this.LabelNotFound.TabIndex = 14;
			this.LabelNotFound.Text = "WARNING: Student not found";
			this.LabelNotFound.Visible = false;
			// 
			// LabelAlreadyLoggedIn
			// 
			this.LabelAlreadyLoggedIn.AutoSize = true;
			this.LabelAlreadyLoggedIn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelAlreadyLoggedIn.ForeColor = System.Drawing.Color.Red;
			this.LabelAlreadyLoggedIn.Location = new System.Drawing.Point(587, 434);
			this.LabelAlreadyLoggedIn.Name = "LabelAlreadyLoggedIn";
			this.LabelAlreadyLoggedIn.Size = new System.Drawing.Size(265, 21);
			this.LabelAlreadyLoggedIn.TabIndex = 15;
			this.LabelAlreadyLoggedIn.Text = "WARNING: Already logged in/out";
			this.LabelAlreadyLoggedIn.Visible = false;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(13, 88);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(134, 17);
			this.label1.TabIndex = 16;
			this.label1.Text = "# of students logged:";
			// 
			// LabelTotalLogCount
			// 
			this.LabelTotalLogCount.AutoSize = true;
			this.LabelTotalLogCount.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LabelTotalLogCount.Location = new System.Drawing.Point(153, 89);
			this.LabelTotalLogCount.Name = "LabelTotalLogCount";
			this.LabelTotalLogCount.Size = new System.Drawing.Size(15, 17);
			this.LabelTotalLogCount.TabIndex = 17;
			this.LabelTotalLogCount.Text = "0";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(872, 483);
			this.Controls.Add(this.LabelTotalLogCount);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.LabelAlreadyLoggedIn);
			this.Controls.Add(this.LabelNotFound);
			this.Controls.Add(this.LabelSessionNotice);
			this.Controls.Add(this.LabelSessionName);
			this.Controls.Add(this.LabelStudentCourse);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.TextBoxRfid);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.LabelLogoutStatus);
			this.Controls.Add(this.LabelLoginStatus);
			this.Controls.Add(this.LabelTimer);
			this.Controls.Add(this.LabelStudentName);
			this.Controls.Add(this.MainMenu);
			this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MainMenuStrip = this.MainMenu;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Attendance Form";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.MainMenu.ResumeLayout(false);
			this.MainMenu.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip MainMenu;
		private System.Windows.Forms.Label LabelStudentName;
		private System.Windows.Forms.Label LabelTimer;
		private System.Windows.Forms.Label LabelLoginStatus;
		private System.Windows.Forms.Label LabelLogoutStatus;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Timer ClockTimer;
		private System.Windows.Forms.ToolStripMenuItem ViewSessionsToolStripMenuItem;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox TextBoxRfid;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label LabelStudentCourse;
		private System.Windows.Forms.Label LabelSessionName;
		private System.Windows.Forms.ToolStripMenuItem viewStudentsToolStripMenuItem;
		private System.Windows.Forms.Label LabelSessionNotice;
		private System.Windows.Forms.ToolStripMenuItem sessionStatusToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem nothingToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
		private System.Windows.Forms.ToolStripMenuItem automaticToolStripMenuItem;
		private System.Windows.Forms.Label LabelNotFound;
		private System.Windows.Forms.Label LabelAlreadyLoggedIn;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label LabelTotalLogCount;
	}
}

