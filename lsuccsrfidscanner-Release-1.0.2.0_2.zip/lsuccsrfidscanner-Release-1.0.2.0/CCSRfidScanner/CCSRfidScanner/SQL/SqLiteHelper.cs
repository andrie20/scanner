﻿using System.Data;
using System.Data.SQLite;

namespace CCSRfidScanner.SQL {
	public class SqLiteHelper : ISQLDatabase {
		private SQLiteConnection database;
		public void Close() {
			database.Close();
		}

		public bool Connect(string ConnectionString) {
			try {
				database = new SQLiteConnection(ConnectionString);
				database.Open();
				return true;
			}
			catch {
				return false;
			}
		}

		public int ExecuteNonQuery(string command) {
			SQLiteCommand sqCommand = new SQLiteCommand(command);
			sqCommand.Connection = database;
			return sqCommand.ExecuteNonQuery();
		}

		public DataTable ExecuteQuery(string query) {
			var myDataTable = new DataTable();

			var databaseCommand = new SQLiteCommand();
			databaseCommand.Connection = database;
			databaseCommand.CommandText = query;

			SQLiteDataAdapter da = new SQLiteDataAdapter(databaseCommand);
			da.Fill(myDataTable);

			return myDataTable;
		}
	}
}
