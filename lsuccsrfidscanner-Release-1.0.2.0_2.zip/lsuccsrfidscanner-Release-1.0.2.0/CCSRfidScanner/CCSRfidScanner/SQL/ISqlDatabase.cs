﻿using System.Data;

namespace CCSRfidScanner.SQL {
	public interface ISQLDatabase {
		/// <summary>
		/// Opens an connection to a file or a server
		/// </summary>
		/// <param name="ConnectionString">Your connection string here</param>
		/// <returns>Returns true if the connection was successful.</returns>
		bool Connect(string ConnectionString);

		/// <summary>
		/// Closes the connection
		/// </summary>
		void Close();
		
		/// <summary>
		/// Executes a query that doesn't return a table. Ex: "INSERT INTO DEPT VALUES (50,'Development','Philadelphia')"
		/// </summary>
		/// <param name="command">SQL Query</param>
		/// <returns>The number of rows affected</returns>
		int ExecuteNonQuery(string command);

		/// <summary>
		/// Executes a query that returns a data table. Ex: "SELECT * FROM table"
		/// </summary>
		/// <param name="query">SQL query</param>
		DataTable ExecuteQuery(string query);
	}
}
