﻿using Microsoft.Office.Interop.Excel;
using System.Drawing;

namespace CCSRfidScanner.Excel {
	class ExcelApp {
		public Application app;
		public Workbook Workbook;
		public Worksheet Worksheet;
		public Range WorksheetRange;

		public ExcelApp(string Sheet1name = "Sheet1") {
			app = new Application();
			Workbook = app.Workbooks.Add(1);
			Worksheet = (Worksheet)Workbook.Sheets[1];
			Worksheet.Name = Sheet1name;
			Worksheet.PrintPreview();
			Worksheet.PageSetup.Orientation = XlPageOrientation.xlPortrait;
			Worksheet.PageSetup.PaperSize = XlPaperSize.xlPaperLetter;
		}

		#region "Get/Set cell values"
		/// <summary>
		/// Sets the value of the given coordinates (x,y) of the excel spreadsheet
		/// </summary>
		/// <param name="x">X-Axis</param>
		/// <param name="y">Y-Axis</param>
		/// <param name="value">The new contents of the cell</param>
		public ExcelApp SetCellValue(int x, int y, dynamic value) {
			Worksheet.Cells[x, y] = value;
			return this;
		}

		/// <summary>
		/// Sets the value of a given cell name.
		/// </summary>
		/// <param name="cell">Cell name. Ex: E5</param>
		/// <param name="value">The new contents of the cell</param>
		public ExcelApp SetCellValue(string cell, dynamic value) {
			WorksheetRange = Worksheet.get_Range(cell);
			WorksheetRange.Value = value;
			return this;
		}

		/// <summary>
		/// Gets a cell and returns its contents in specified object type
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="cell">Cell name. Ex: E5</param>
		/// <returns></returns>
		public T GetCellValue<T>(string cell) {
			WorksheetRange = Worksheet.get_Range(cell);
			return WorksheetRange.Value;
		}
		#endregion

		#region "Column and Rows Width and Height"
		/// <summary>
		/// Sets column width
		/// </summary>
		/// <param name="ColIndex">Column index in integer</param>
		public ExcelApp SetColumnWidth(string ColIndex, double width) {
			Worksheet.Columns[ColIndex].ColumnWidth = width;
			return this;
		}

		/// <summary>
		/// Sets column width
		/// </summary>
		/// <param name="ColIndex">Column index in string</param>
		public ExcelApp SetColumnWidth(int ColIndex, double width) {
			Worksheet.Columns[ColIndex].ColumnWidth = width;
			return this;
		}

		/// <summary>
		/// Sets row height
		/// </summary>
		/// <param name="ColIndex">Height index in string</param>
		public ExcelApp SetRowHeight(string RowIndex, double height) {
			Worksheet.Rows[RowIndex].RowHeight = height;
			return this;
		}

		/// <summary>
		/// Sets row height
		/// </summary>
		/// <param name="ColIndex">Height index in integer</param>
		public ExcelApp SetRowHeight(int RowIndex, double height) {
			Worksheet.Rows[RowIndex].RowHeight = height;
			return this;
		}
		#endregion

		#region "Cell formatting"
		/// <summary>
		/// Clears formats of the cell and sets it back to defaults
		/// </summary>
		/// <param name="cell">Cell names. Ex: A1:B6</param>
		public ExcelApp ClearFormat(string cell) {
			WorksheetRange = Worksheet.get_Range(cell);
			WorksheetRange.ClearFormats();
			return this;
		}

		/// <summary>
		/// Formats the cell font
		/// </summary>
		/// <param name="cell">Cell names. Ex: A1:B6</param>
		public ExcelApp FormatFont(string cell, Color FontColor, int FontSize = 11, string FontName = "Calibri", bool IsBold = false, bool Italic = false, bool Underline = false, bool Strikethrough = false) {
			WorksheetRange = Worksheet.get_Range(cell);
			WorksheetRange.Font.Color = FontColor;
			WorksheetRange.Font.Name = FontName;
			WorksheetRange.Font.Size = FontSize;
			WorksheetRange.Font.Italic = Italic;
			WorksheetRange.Font.Bold = IsBold;
			WorksheetRange.Font.Underline = Underline;
			WorksheetRange.Font.Strikethrough = Strikethrough;
			return this;
		}

		/// <summary>
		/// Formats cell borders
		/// </summary>
		/// <param name="cell">Cell names. Ex: A1:B6</param>
		/// <param name="BorderSize">Size in pixels</param>
		public ExcelApp FormatCellBorder(string cell, Color BorderColor, int BorderSize = 0) {
			WorksheetRange = Worksheet.get_Range(cell);
			WorksheetRange.Borders.Color = BorderColor;
			WorksheetRange.Borders.Weight = BorderSize;
			return this;
		}

		/// <summary>
		/// Sets the cell background color
		/// </summary>
		/// <param name="cell">Cell names. Ex: A1:B6</param>
		public ExcelApp FormatCell(string cell, Color BackgroundColor) {
			WorksheetRange = Worksheet.get_Range(cell);
			WorksheetRange.Interior.Color = BackgroundColor;
			return this;
		}

		/// <summary>
		/// Merges selected cells.
		/// </summary>
		/// <param name="cell">Cell names. Ex: A1:B6</param>
		public ExcelApp MergeCells(string cell) {
			WorksheetRange = Worksheet.get_Range(cell);
			WorksheetRange.Merge();
			return this;
		}

		/// <summary>
		/// Sets the text direction of the cell
		/// </summary>
		/// <param name="cell">Cell names. Ex: A1:B6</param>
		public ExcelApp SetCellTextDirection(string cell, XlHAlign HAlign = XlHAlign.xlHAlignLeft, XlVAlign VAlign = XlVAlign.xlVAlignBottom) {
			WorksheetRange = Worksheet.get_Range(cell);
			WorksheetRange.VerticalAlignment = HAlign;
			WorksheetRange.HorizontalAlignment = VAlign;
			return this;
		}
		#endregion
	}
}
