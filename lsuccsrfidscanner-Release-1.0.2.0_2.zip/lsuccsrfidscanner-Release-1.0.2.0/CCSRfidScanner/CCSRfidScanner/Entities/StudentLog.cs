﻿using CCSRfidScanner.SQL;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace CCSRfidScanner.Entities {
	public class StudentLog {
		public long? StudentLogsId { get; set; }
		public long StudentId { get; set; }
		public long SessionId { get; set; }
		public long LogType { get; set; }
	}

	public class StudentLogHelper {
		private ISQLDatabase _database;
		private const string _tableName = "TStudentLogs";
		public string[] _fields = new string[] { "StudentLogsId", "StudentId", "SessionId", "LogType" };

		private StudentLog ParseRow(DataRow row) {
			return row == null ? null :
				new StudentLog {
					StudentLogsId = row.Field<long>("StudentLogsId"),
					StudentId = row.Field<long>("StudentId"),
					SessionId = row.Field<long>("SessionId"),
					LogType = row.Field<long>("LogType")
				};
		}
		private IEnumerable<StudentLog> ParseRows(DataRowCollection rows) {
			var studentLogs = new List<StudentLog> { };

			foreach (DataRow row in rows) {
				studentLogs.Add(ParseRow(row));
			}

			return studentLogs;
		}

		public StudentLogHelper(ISQLDatabase database) {
			_database = database;
		}

		public IEnumerable<StudentLog> Find(string query) {
			return ParseRows(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0} WHERE {2}", _tableName, string.Join(", ", _fields), query)).Rows);
		}
		public IEnumerable<StudentLog> FindAll() {
			return ParseRows(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0}", _tableName, string.Join(", ", _fields))).Rows);
		}
		public StudentLog FindOne(string query) {
			return ParseRow(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0} WHERE {2}", _tableName, string.Join(", ", _fields), query)).Rows.Cast<DataRow>().DefaultIfEmpty(null).FirstOrDefault());
		}

		public int Delete(string query) {
			return _database.ExecuteNonQuery(string.Format("DELETE FROM {0} WHERE {1}", _tableName, query));
		}
		public int Delete(StudentLog studentLog) {
			return _database.ExecuteNonQuery(string.Format("DELETE FROM {0} WHERE {1}={2}", _tableName, _fields[0], studentLog.StudentLogsId));
		}

		public void Insert(StudentLog studentLog) {
			_database.ExecuteNonQuery(string.Format("INSERT INTO {0} ({1}) Values({2}, {3}, {4})",
				_tableName, string.Join(", ", _fields.Skip(1)),
				studentLog.StudentId,
				studentLog.SessionId,
				studentLog.LogType
			));
		}

		public int Update(string update, string query) {
			return _database.ExecuteNonQuery(string.Format("UPDATE {0} SET {1} WHERE {2}", _tableName, update, query));
		}
	}
}
