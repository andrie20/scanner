﻿namespace CCSRfidScanner {
	partial class FormStudents {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.ListViewStudents = new System.Windows.Forms.ListView();
            this.ColumnStudentName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnStudentIdNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnStudentRfId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ColumnStudentCourse = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ContextMenuStudents = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GroupBoxAddStudent = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TextBoxStudentCourse = new System.Windows.Forms.TextBox();
            this.TextBoxStudentName = new System.Windows.Forms.TextBox();
            this.TextBoxRfIdCode = new System.Windows.Forms.TextBox();
            this.TextBoxIdNum = new System.Windows.Forms.TextBox();
            this.ButtonCancelAction = new System.Windows.Forms.Button();
            this.ButtonSave = new System.Windows.Forms.Button();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.addStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importCSVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportCSVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.rightclickARowToEditdeleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStudents.SuspendLayout();
            this.GroupBoxAddStudent.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // ListViewStudents
            // 
            this.ListViewStudents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColumnStudentName,
            this.ColumnStudentIdNum,
            this.ColumnStudentRfId,
            this.ColumnStudentCourse});
            this.ListViewStudents.ContextMenuStrip = this.ContextMenuStudents;
            this.ListViewStudents.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListViewStudents.FullRowSelect = true;
            this.ListViewStudents.HideSelection = false;
            this.ListViewStudents.Location = new System.Drawing.Point(12, 27);
            this.ListViewStudents.MultiSelect = false;
            this.ListViewStudents.Name = "ListViewStudents";
            this.ListViewStudents.Size = new System.Drawing.Size(635, 404);
            this.ListViewStudents.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.ListViewStudents.TabIndex = 0;
            this.ListViewStudents.UseCompatibleStateImageBehavior = false;
            this.ListViewStudents.View = System.Windows.Forms.View.Details;
            this.ListViewStudents.SelectedIndexChanged += new System.EventHandler(this.ListViewStudents_SelectedIndexChanged);
            // 
            // ColumnStudentName
            // 
            this.ColumnStudentName.Text = "Name";
            this.ColumnStudentName.Width = 200;
            // 
            // ColumnStudentIdNum
            // 
            this.ColumnStudentIdNum.Text = "ID Number";
            this.ColumnStudentIdNum.Width = 120;
            // 
            // ColumnStudentRfId
            // 
            this.ColumnStudentRfId.Text = "RFID Code";
            this.ColumnStudentRfId.Width = 160;
            // 
            // ColumnStudentCourse
            // 
            this.ColumnStudentCourse.Text = "Course";
            this.ColumnStudentCourse.Width = 150;
            // 
            // ContextMenuStudents
            // 
            this.ContextMenuStudents.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.ContextMenuStudents.Name = "ContextMenuStudents";
            this.ContextMenuStudents.Size = new System.Drawing.Size(108, 48);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.deleteToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // GroupBoxAddStudent
            // 
            this.GroupBoxAddStudent.Controls.Add(this.label4);
            this.GroupBoxAddStudent.Controls.Add(this.label3);
            this.GroupBoxAddStudent.Controls.Add(this.label2);
            this.GroupBoxAddStudent.Controls.Add(this.label1);
            this.GroupBoxAddStudent.Controls.Add(this.TextBoxStudentCourse);
            this.GroupBoxAddStudent.Controls.Add(this.TextBoxStudentName);
            this.GroupBoxAddStudent.Controls.Add(this.TextBoxRfIdCode);
            this.GroupBoxAddStudent.Controls.Add(this.TextBoxIdNum);
            this.GroupBoxAddStudent.Controls.Add(this.ButtonCancelAction);
            this.GroupBoxAddStudent.Controls.Add(this.ButtonSave);
            this.GroupBoxAddStudent.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxAddStudent.Location = new System.Drawing.Point(12, 329);
            this.GroupBoxAddStudent.Name = "GroupBoxAddStudent";
            this.GroupBoxAddStudent.Size = new System.Drawing.Size(635, 102);
            this.GroupBoxAddStudent.TabIndex = 5;
            this.GroupBoxAddStudent.TabStop = false;
            this.GroupBoxAddStudent.Text = "Edit Student";
            this.GroupBoxAddStudent.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(500, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Course";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(358, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "RFID Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(236, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "ID Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Name";
            // 
            // TextBoxStudentCourse
            // 
            this.TextBoxStudentCourse.Location = new System.Drawing.Point(503, 40);
            this.TextBoxStudentCourse.MaxLength = 10;
            this.TextBoxStudentCourse.Name = "TextBoxStudentCourse";
            this.TextBoxStudentCourse.Size = new System.Drawing.Size(126, 25);
            this.TextBoxStudentCourse.TabIndex = 4;
            // 
            // TextBoxStudentName
            // 
            this.TextBoxStudentName.Location = new System.Drawing.Point(6, 40);
            this.TextBoxStudentName.Name = "TextBoxStudentName";
            this.TextBoxStudentName.Size = new System.Drawing.Size(227, 25);
            this.TextBoxStudentName.TabIndex = 1;
            // 
            // TextBoxRfIdCode
            // 
            this.TextBoxRfIdCode.Location = new System.Drawing.Point(361, 40);
            this.TextBoxRfIdCode.Name = "TextBoxRfIdCode";
            this.TextBoxRfIdCode.Size = new System.Drawing.Size(136, 25);
            this.TextBoxRfIdCode.TabIndex = 3;
            // 
            // TextBoxIdNum
            // 
            this.TextBoxIdNum.Location = new System.Drawing.Point(239, 40);
            this.TextBoxIdNum.Name = "TextBoxIdNum";
            this.TextBoxIdNum.Size = new System.Drawing.Size(116, 25);
            this.TextBoxIdNum.TabIndex = 2;
            // 
            // ButtonCancelAction
            // 
            this.ButtonCancelAction.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelAction.Location = new System.Drawing.Point(473, 71);
            this.ButtonCancelAction.Name = "ButtonCancelAction";
            this.ButtonCancelAction.Size = new System.Drawing.Size(75, 23);
            this.ButtonCancelAction.TabIndex = 5;
            this.ButtonCancelAction.Text = "Cancel";
            this.ButtonCancelAction.UseVisualStyleBackColor = true;
            this.ButtonCancelAction.Click += new System.EventHandler(this.ButtonCancelAction_Click);
            // 
            // ButtonSave
            // 
            this.ButtonSave.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSave.Location = new System.Drawing.Point(554, 71);
            this.ButtonSave.Name = "ButtonSave";
            this.ButtonSave.Size = new System.Drawing.Size(75, 23);
            this.ButtonSave.TabIndex = 6;
            this.ButtonSave.Text = "&Save changes";
            this.ButtonSave.UseVisualStyleBackColor = true;
            this.ButtonSave.Click += new System.EventHandler(this.ButtonSave_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudentToolStripMenuItem,
            this.importCSVToolStripMenuItem,
            this.exportCSVToolStripMenuItem,
            this.rightclickARowToEditdeleteToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(661, 25);
            this.MainMenu.TabIndex = 8;
            this.MainMenu.Text = "menuStrip1";
            // 
            // addStudentToolStripMenuItem
            // 
            this.addStudentToolStripMenuItem.Name = "addStudentToolStripMenuItem";
            this.addStudentToolStripMenuItem.Size = new System.Drawing.Size(91, 21);
            this.addStudentToolStripMenuItem.Text = "Add student";
            this.addStudentToolStripMenuItem.Click += new System.EventHandler(this.addStudentToolStripMenuItem_Click);
            // 
            // importCSVToolStripMenuItem
            // 
            this.importCSVToolStripMenuItem.Name = "importCSVToolStripMenuItem";
            this.importCSVToolStripMenuItem.Size = new System.Drawing.Size(86, 21);
            this.importCSVToolStripMenuItem.Text = "Import CSV";
            this.importCSVToolStripMenuItem.Click += new System.EventHandler(this.importCSVToolStripMenuItem_Click);
            // 
            // exportCSVToolStripMenuItem
            // 
            this.exportCSVToolStripMenuItem.Name = "exportCSVToolStripMenuItem";
            this.exportCSVToolStripMenuItem.Size = new System.Drawing.Size(85, 21);
            this.exportCSVToolStripMenuItem.Text = "Export CSV";
            this.exportCSVToolStripMenuItem.Click += new System.EventHandler(this.exportCSVToolStripMenuItem_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "CSV file|*.csv|TXT file|*.txt";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "CSV file|*.csv|TXT file|*.txt";
            // 
            // rightclickARowToEditdeleteToolStripMenuItem
            // 
            this.rightclickARowToEditdeleteToolStripMenuItem.Enabled = false;
            this.rightclickARowToEditdeleteToolStripMenuItem.Name = "rightclickARowToEditdeleteToolStripMenuItem";
            this.rightclickARowToEditdeleteToolStripMenuItem.Size = new System.Drawing.Size(204, 21);
            this.rightclickARowToEditdeleteToolStripMenuItem.Text = "(right-click a row to edit/delete)";
            // 
            // FormStudents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 443);
            this.Controls.Add(this.MainMenu);
            this.Controls.Add(this.GroupBoxAddStudent);
            this.Controls.Add(this.ListViewStudents);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.MainMenu;
            this.Name = "FormStudents";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "View Students";
            this.Load += new System.EventHandler(this.FormStudents_Load);
            this.ContextMenuStudents.ResumeLayout(false);
            this.GroupBoxAddStudent.ResumeLayout(false);
            this.GroupBoxAddStudent.PerformLayout();
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListView ListViewStudents;
		private System.Windows.Forms.ColumnHeader ColumnStudentIdNum;
		private System.Windows.Forms.ColumnHeader ColumnStudentRfId;
		private System.Windows.Forms.ColumnHeader ColumnStudentName;
		private System.Windows.Forms.ColumnHeader ColumnStudentCourse;
		private System.Windows.Forms.ContextMenuStrip ContextMenuStudents;
		private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
		private System.Windows.Forms.GroupBox GroupBoxAddStudent;
		private System.Windows.Forms.TextBox TextBoxStudentCourse;
		private System.Windows.Forms.TextBox TextBoxStudentName;
		private System.Windows.Forms.TextBox TextBoxRfIdCode;
		private System.Windows.Forms.TextBox TextBoxIdNum;
		private System.Windows.Forms.Button ButtonCancelAction;
		private System.Windows.Forms.Button ButtonSave;
		private System.Windows.Forms.MenuStrip MainMenu;
		private System.Windows.Forms.ToolStripMenuItem addStudentToolStripMenuItem;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.ToolStripMenuItem importCSVToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem exportCSVToolStripMenuItem;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem rightclickARowToEditdeleteToolStripMenuItem;
    }
}