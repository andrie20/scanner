using CCSRfidScanner.Entities;
using CCSRfidScanner.Excel;
using CCSRfidScanner.SQL;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace CCSRfidScanner {
    public partial class FormSessions : Form {
		private ISQLDatabase _database;
		private SessionHelper _sessionHelper;
		private StudentLogHelper _studentLogHelper;

		public Session SelectedSession = null;
		public bool ShowAddSession = true;

		#region "Form Functions"
		public FormSessions(ISQLDatabase database, bool ShowAddSession = true) {
			_database = database;
			_sessionHelper = new SessionHelper(_database);
			_studentLogHelper = new StudentLogHelper(_database);

			this.ShowAddSession = ShowAddSession;
			InitializeComponent();

			// initialize event handlers
			ListViewSessions.DoubleClick += ListViewSessions_DoubleClick;
			ListViewSessions.KeyUp += ListViewSessions_KeyUp;
		}

		private void FormSessions_Load(object sender, EventArgs e) {
			// Load sessions into list view
			foreach (var session in _sessionHelper.FindAll()) {
				try {
					ListViewSessions.Items.Add(new ListViewItem(
						new string[] {
							session.SessionId.ToString(),
							session.SessionName,
							session.StartDateTime.ToString(),
							session.EndDateTime.ToString(),
							session.LogMinutesInterval.ToString()
						}
					));
				}
				catch (Exception ex) {
					Extensions.LogError(ex);
				}
			}

			if (!ShowAddSession) {
				Height = 338;
				GroupBoxAddSession.Enabled = false;
			}
		}
		#endregion

		#region "ListViewSessions Functions"
		private void ListViewSessions_KeyUp(object sender, KeyEventArgs e) {
			if (e.KeyData == Keys.Enter) {
				ButtonSelectSession_Click(null, null);
			}
		}

		private void ListViewSessions_DoubleClick(object sender, EventArgs e) {
			if (ListViewSessions.SelectedItems.Count == 1) {
				ButtonSelectSession_Click(null, null);
			}
		}

		private void ListViewSessions_SelectedIndexChanged(object sender, EventArgs e) {
			if (ListViewSessions.SelectedItems.Count == 1) {
				ButtonSelectSession.Enabled = true;
				ButtonViewReport.Enabled = true;
				ToolStripDeleteSession.Enabled = true;
			}
			else {
				ButtonSelectSession.Enabled = false;
				ButtonViewReport.Enabled = false;
				ToolStripDeleteSession.Enabled = false;
			}
		}
		#endregion

		private void ButtonSelectSession_Click(object sender, EventArgs e) {
			try {
				if (ListViewSessions.SelectedItems.Count == 1) {
					SelectedSession = _sessionHelper.FindOne("SessionId=" + ListViewSessions.SelectedItems[0].SubItems[0].Text);

					Close();
				}
			}
			catch (Exception ex) {
				Extensions.LogError(ex);
			}
		}

		private void ButtonViewReport_Click(object sender, EventArgs e) {
			try {
				// get sessions' id's
				long CurrentAMSessionId = -1;
				long CurrentPMSessionId = -1;
				if (ListViewSessions.SelectedItems[0].SubItems[1].Text.EndsWith(" PM")) {
					CurrentPMSessionId = long.Parse(ListViewSessions.SelectedItems[0].SubItems[0].Text);

					// find AM session
					var AMSessionItem = ListViewSessions.Items.Cast<ListViewItem>().Where(x => x.SubItems[1].Text == (ListViewSessions.SelectedItems[0].SubItems[1].Text.Replace(" PM", "") + " AM"));
					if (AMSessionItem.Count() == 1) {
						if (MessageBox.Show(string.Format("Do you want to use session {0} as AM session?",
							AMSessionItem.ElementAt(0).SubItems[1].Text), Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
							CurrentAMSessionId = long.Parse(AMSessionItem.ElementAt(0).SubItems[0].Text);
					}
				}
				else { // default is AM
					CurrentAMSessionId = long.Parse(ListViewSessions.SelectedItems[0].SubItems[0].Text);

					// find PM session
					var PMSessionItem = ListViewSessions.Items.Cast<ListViewItem>().Where(x => x.SubItems[1].Text == (ListViewSessions.SelectedItems[0].SubItems[1].Text.Replace(" AM", "") + " PM"));
					if (PMSessionItem.Count() == 1) {
						if (MessageBox.Show(string.Format("Do you want to use session {0} as PM session?",
							PMSessionItem.ElementAt(0).SubItems[1].Text), Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
							CurrentPMSessionId = long.Parse(PMSessionItem.ElementAt(0).SubItems[0].Text);
					}
				}
				string CurrentSessionName = ListViewSessions.SelectedItems[0].SubItems[1].Text;

				UseWaitCursor = true;
				Enabled = false;
				Application.DoEvents();

				// get students
				var students = new DataTable[5];
				int count = 0;
				for (int i = 1; i <= 5; i++) {
					students[i - 1] = _database.ExecuteQuery(string.Format("SELECT * FROM TStudents WHERE Course LIKE '%-{0}' ORDER BY Course, Name ASC", i));
					count += students[i - 1].Rows.Count;
				}

				// set progress bar
				ProgressBarViewReport.Value = 0;
				ProgressBarViewReport.Maximum = count;
				ProgressBarViewReport.Visible = true;

				// prepare excel
				var excel = new ExcelApp();
				int currentWorksheetIndex = 0;
				excel.app.Visible = false;
				excel.app.DisplayAlerts = false;


				for (int i = 4; i >= 0; i--) { // loop through 5 levels
					var student = students[i];

					if (student.Rows.Count > 0) { // check if students count is greater than 1

						if(excel.app.Worksheets.Count < (currentWorksheetIndex + 1)) {
							// check if not the first worksheet
							excel.app.Worksheets.Add();//After: excel.Workbook.Sheets[excel.Workbook.Sheets.Count]
							excel.Worksheet = (Microsoft.Office.Interop.Excel.Worksheet)excel.Workbook.Worksheets[1];
							excel.Worksheet.Activate();
						}

						excel.Worksheet.Name = "Year Level " + (i + 1);
						excel.Worksheet.PageSetup.TopMargin = excel.app.InchesToPoints(0.5);
						excel.Worksheet.PageSetup.RightMargin = excel.app.InchesToPoints(0.5);
						excel.Worksheet.PageSetup.BottomMargin = excel.app.InchesToPoints(0.5);
						excel.Worksheet.PageSetup.LeftMargin = excel.app.InchesToPoints(0.5);

						// headers
						excel.SetCellValue("A1", "LA SALLE UNIVERSITY")
							.MergeCells("A1:G1")
							.FormatFont("A1", Color.Black, 14, "Century Gothic", true)

							.SetCellValue("A2", "COLLEGE OF COMPUTER STUDIES")
							.MergeCells("A2:G2")
							.FormatFont("A2", Color.Black, 12, "Century Gothic", true)

							.SetCellValue("A3", "St. Columban Drive, Valconcha St.,")
							.MergeCells("A3:G3")
							.FormatFont("A3", Color.Black, 11, "Century Gothic")

							.SetCellValue("A4", "Aguada, Ozamiz City")
							.MergeCells("A4:G4")
							.FormatFont("A4", Color.Black, 11, "Century Gothic")

							.SetCellValue("A6", "---")
							.MergeCells("A6:G6")
							.FormatFont("A6", Color.Black, 13, "Century Gothic", true)

							.SetCellValue("A8", CurrentSessionName.Substring(0, CurrentSessionName.Length - 3)) // remove AM/PM
							.MergeCells("A8:G8")
							.FormatFont("A8", Color.Black, 13, "Century Gothic", true)

							.SetCellValue("A9", "Year Level: " + (i + 1))
							.MergeCells("A9:G9")
							.FormatFont("A9", Color.Black, 13, "Century Gothic", true)
							
							.SetCellTextDirection("A1:G9", Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter, Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter);

						int currentRow = 11;

						// set row headers
						excel.SetCellValue("D" + currentRow, "AM")
							.SetCellValue("F" + currentRow, "PM")
							.SetCellValue("A" + currentRow, "ID")
							.SetCellValue("B" + currentRow, "Name")
							.SetCellValue("C" + currentRow, "Course")
							.SetCellValue("D" + (currentRow + 1), "Login")
							.SetCellValue("E" + (currentRow + 1), "Logout")
							.SetCellValue("F" + (currentRow + 1), "Login")
							.SetCellValue("G" + (currentRow + 1), "Logout")
							.SetColumnWidth(1, 11.71)
							.SetColumnWidth(2, 43.29)
							.SetColumnWidth(3, 8.71)
							.SetColumnWidth("D:G", 6.5)
							.MergeCells("A" + currentRow + ":A" + (currentRow + 1))
							.MergeCells("B" + currentRow + ":B" + (currentRow + 1))
							.MergeCells("C" + currentRow + ":C" + (currentRow + 1))
							.MergeCells("D" + currentRow + ":E" + currentRow)
							.MergeCells("F" + currentRow + ":G" + currentRow)
							.FormatFont("A" + currentRow + ":G" + (currentRow + 1), Color.Black, 12, "Century Gothic", true)
							.FormatFont("D" + (currentRow + 1) + ":G" + (currentRow + 1), Color.Black, 10, "Century Gothic", true)
							//.FormatFont("A" + (currentRow + 2) + "):G" + currentRow, Color.Black, 12, "Century Gothic")
							.SetCellTextDirection("A" + currentRow + ":G" + (currentRow + 1), Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter, Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter);


						currentRow += 2;

						// loop through the student list and display if he is logged in or not
						foreach (DataRow row in student.Rows) {
							excel.SetCellValue("A" + currentRow.ToString(), row.ItemArray[1].ToString());
							excel.SetCellValue("B" + currentRow.ToString(), row.ItemArray[3].ToString());
							excel.SetCellValue("C" + currentRow.ToString(), row.ItemArray[4].ToString());

							if (CurrentAMSessionId != -1) {
								// has AM session
								if (_database.ExecuteQuery(string.Format("SELECT * FROM TStudentLogs WHERE StudentId = {0} AND SessionId = {1} AND LogType = 1",
											row.ItemArray[0], CurrentAMSessionId)).Rows.Count > 0) {
									// logged in
									excel.SetCellValue("D" + currentRow.ToString(), "YES");
								}

								if (_database.ExecuteQuery(string.Format("SELECT * FROM TStudentLogs WHERE StudentId = {0} AND SessionId = {1} AND LogType = 2",
											row.ItemArray[0], CurrentAMSessionId)).Rows.Count > 0) {
									// logged out
									excel.SetCellValue("E" + currentRow.ToString(), "YES");
								}
							}
							else {
								// does not have AM session
								excel.FormatCell("D" + currentRow.ToString(), Color.LightGray)
									.FormatCell("E" + currentRow.ToString(), Color.LightGray);
							}

							if (CurrentPMSessionId != -1) {
								// has PM session
								if (_database.ExecuteQuery(string.Format("SELECT * FROM TStudentLogs WHERE StudentId = {0} AND SessionId = {1} AND LogType = 1",
											row.ItemArray[0], CurrentPMSessionId)).Rows.Count > 0) {
									// logged in
									excel.SetCellValue("F" + currentRow.ToString(), "YES");
								}

								if (_database.ExecuteQuery(string.Format("SELECT * FROM TStudentLogs WHERE StudentId = {0} AND SessionId = {1} AND LogType = 2",
											row.ItemArray[0], CurrentPMSessionId)).Rows.Count > 0) {
									// logged out
									excel.SetCellValue("G" + currentRow.ToString(), "YES");
								}
							}
							else {
								// does not have PM session
								excel.FormatCell("F" + currentRow.ToString(), Color.LightGray)
									.FormatCell("G" + currentRow.ToString(), Color.LightGray);
							}
							excel.FormatFont("A" + currentRow + ":G" + currentRow, Color.Black, 12, "Century Gothic")
								.SetRowHeight(currentRow, 29.25);

							currentRow++;
							ProgressBarViewReport.Value++;
							Application.DoEvents();

						} // <-- foreach (...)

						currentWorksheetIndex++;
					} // <-- if (...)
				} // <-- for (...)

				excel.app.Visible = true;
			}
			catch (Exception ex){
				Extensions.LogError(ex);
			}
			Enabled = true;
			UseWaitCursor = false;
			ProgressBarViewReport.Visible = false;
		}

		private void ToolStripDeleteSession_Click(object sender, EventArgs e) {
			try {
				if (MessageBox.Show(string.Format("WARNING: You are about to delete the session {0} and all related information. Are you sure you want to continue?", ListViewSessions.SelectedItems[0].SubItems[1].Text), Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {
					var SessionId = long.Parse(ListViewSessions.SelectedItems[0].SubItems[0].Text);

					_studentLogHelper.Delete("SessionId=" + SessionId);
					_sessionHelper.Delete("SessionId=" + SessionId);

					ListViewSessions.SelectedItems[0].Remove();
				}
			}
			catch (Exception ex) {
				Extensions.LogError(ex);
			}
		}

		private void ButtonViewsStudents_Click(object sender, EventArgs e) {
			FormStudents formstudents = new FormStudents(_database);
			formstudents.ShowDialog();
		}

		private void ButtonAddSession_Click(object sender, EventArgs e) {
			string NewSessionName = TextBoxSessionName.Text.Replace("'", "\\'");
			var LogInterval = (long)NumUpDownLoggingInterval.Value;

			// Check for empty inputs
			if (string.IsNullOrWhiteSpace(NewSessionName)) {
				MessageBox.Show("Please fill in all fields.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			// Check for AM/PM in the session name
			if (!NewSessionName.EndsWith(" AM") && !NewSessionName.EndsWith(" PM")) {
				MessageBox.Show("Please indicate AM/PM session at the end of the session name.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			// Check if DateTime is too near
			if (DateTimeStartDateTime.Value.AddMinutes(LogInterval) > DateTimeEndDateTime.Value) {
				MessageBox.Show("Login Date/Time and Logout Date/Time are too near.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			// Check session name if already on the list
			try {
				if (_sessionHelper.Find("SessionName='" + NewSessionName + "'").Count() > 0) {
					MessageBox.Show("That session name seems to be already on the list.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}
			catch { }

			// Execute query
			try {
				_sessionHelper.Insert(new Session {
					SessionName = NewSessionName,
					StartDateTime = DateTimeStartDateTime.Value,
					EndDateTime = DateTimeEndDateTime.Value,
					LogMinutesInterval = LogInterval
				});

				SelectedSession = _sessionHelper.FindOne("SessionName='" + NewSessionName + "'");
				Close();
			}
			catch (Exception ex) {
				Extensions.LogError(ex);
			}
		}
	}
}
