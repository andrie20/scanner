using CCSRfidScanner.Entities;
using CCSRfidScanner.SQL;
using CsvHelper;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CCSRfidScanner {
    public partial class FormStudents : Form {
		private ISQLDatabase _database;
		private StudentHelper _studentHelper;
		private StudentLogHelper _studentLogHelper;
		int currentStatus = 0;
		int currentStudentIndex = -1; // ID of current student editing

		#region "Local Functions"
		private void RefreshStudents() {
			try {
				ListViewStudents.Items.Clear();

				foreach (var student in _studentHelper.FindAll()) {
					ListViewStudents.Items.Add(new ListViewItem(new string[] {
						student.Name,
						student.IDNumber.ToString(),
						student.RFID.ToString(),
						student.Course
					}));
				}
			}
			catch (Exception ex) {
				Extensions.LogError(ex);
			}
		}
		private Student ParseFields(string studentName, string idNumber, string rfidNumber, string course) {
			studentName = studentName.Trim();
			idNumber = idNumber.Trim();
			rfidNumber = rfidNumber.Trim();
			course = course.Trim();

			long validatedIdNumber;
			long? validatedRfidNumber = null;

			if (string.IsNullOrEmpty(studentName)) throw new ValidationException("Student Name field is empty.");
			if (string.IsNullOrEmpty(idNumber)) throw new ValidationException("Student ID Number field is empty.");
			if (string.IsNullOrEmpty(course)) throw new ValidationException("Student Course field is empty.");

			if (!long.TryParse(idNumber, out validatedIdNumber)) throw new ValidationException("Student ID Number field is invalid.");
			long testHolder;
			if (!string.IsNullOrEmpty(rfidNumber)) {
				if (long.TryParse(rfidNumber, out testHolder)) validatedRfidNumber = testHolder;
				else throw new ValidationException("Student RFID field is invalid.");
			}

			return new Student {
				IDNumber = validatedIdNumber,
				RFID = validatedRfidNumber,
				Name = studentName,
				Course = course
			};
		}
		private void ToggleFields() {
			ListViewStudents.Enabled = !ListViewStudents.Enabled;
			GroupBoxAddStudent.Visible = !GroupBoxAddStudent.Visible;
		}
		private void ResetFields() {
			TextBoxStudentName.Text = "";
			TextBoxIdNum.Text = "";
			TextBoxRfIdCode.Text = "";
			TextBoxStudentCourse.Text = "";
		}
		#endregion

		#region "Form Functions"
		public FormStudents(ISQLDatabase database) {
			_database = database;
			_studentHelper = new StudentHelper(_database);
			_studentLogHelper = new StudentLogHelper(_database);
			InitializeComponent();
		}
		private void FormStudents_Load(object sender, EventArgs e) {
			RefreshStudents();
		}
		#endregion

		#region "ListViewStudents Functions"
		private void ListViewStudents_SelectedIndexChanged(object sender, EventArgs e) {
			if (ListViewStudents.SelectedItems.Count == 1) {
				ListViewStudents.ContextMenuStrip = ContextMenuStudents;
			}
			else {
				ListViewStudents.ContextMenuStrip = null;
			}

		}
		#endregion

		#region "Main Menu Functions"
		private void addStudentToolStripMenuItem_Click(object sender, EventArgs e) {
			ToggleFields();
			ResetFields();
			GroupBoxAddStudent.Text = "Add Student";
			currentStatus = 1;
		}
		private void exportCSVToolStripMenuItem_Click(object sender, EventArgs e) {
			try {
				if (saveFileDialog1.ShowDialog() == DialogResult.OK) {
					var fileWriter = File.CreateText(saveFileDialog1.FileName);
					var csvWriter = new CsvWriter(fileWriter);
					csvWriter.WriteRecords(_studentHelper.FindAll());
					fileWriter.Close();
				}
			}
			catch (Exception ex) {
				Extensions.LogError(ex);
			}
		}
		private void importCSVToolStripMenuItem_Click(object sender, EventArgs e) {
			UseWaitCursor = true;
			Enabled = false;
			try {
				if (MessageBox.Show("This will: 1) update existing students to their respective information provided by a csv file, 2) add student if student does not exists in records, and 3) deletes a student in record if not provided in CSV file. Would you like to proceed? CSV Headers are: IDNumber, RFID, Name, Course in any order.", Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {
					if (openFileDialog1.ShowDialog() == DialogResult.OK) {
						var fileReader = File.OpenText(openFileDialog1.FileName);
						var csvReader = new CsvReader(fileReader);

						var students = _studentHelper.FindAll().ToList();

						while (csvReader.Read()) {
							var currentIdNumber = csvReader.GetField<long>("IDNumber");

							var student = students.Where(x => x.IDNumber == currentIdNumber).DefaultIfEmpty(null).FirstOrDefault();
							var csvStudent = new Student {
								IDNumber = currentIdNumber,
								RFID = csvReader.GetField<long?>("RFID"),
								Name = csvReader.GetField<string>("Name"),
								Course = csvReader.GetField<string>("Course"),
							};

							if (student != null) {
								_studentHelper.Update(string.Format("RFID = {0}, Name = '{1}', Course = '{2}'",
									csvReader.GetField<long?>("RFID") == null ? "null" : csvReader.GetField<long?>("RFID").ToString(),
									csvReader.GetField<string>("Name"),
									csvReader.GetField<string>("Course")),
								"IDNumber=" + currentIdNumber);
								students.Remove(student);
							}
							else {
								_studentHelper.Insert(csvStudent);
							}
						}

						// remove extra students
						foreach (var student in students) {
							_studentLogHelper.Delete("StudentId=" + student.StudentId);
							_studentHelper.Delete(student);
						}

						// refresh student list
						RefreshStudents();

						fileReader.Close();
					}

				}
			}
			catch (Exception ex) {
				Extensions.LogError(ex);
			}
			UseWaitCursor = false;
			Enabled = true;
		}
		#endregion

		#region "Group Box Functions"
		private void ButtonCancelAction_Click(object sender, EventArgs e) {
			ToggleFields();

			currentStatus = 0;
		}

		private void ButtonSave_Click(object sender, EventArgs e) {
			try {
				var student = ParseFields(TextBoxStudentName.Text, TextBoxIdNum.Text, TextBoxRfIdCode.Text, TextBoxStudentCourse.Text);

				if (currentStatus == 1) { // Add student
					// insert into table
					_studentHelper.Insert(student);
					ListViewStudents.Items.Add(new ListViewItem(new string[] {
						student.Name,
						student.IDNumber.ToString(),
						student.RFID.ToString(),
						student.Course
					}));
				}
				else { // Edit student
					// update table
					_studentHelper.Update(string.Format("IDNumber = '{0}', RFID = '{1}', Name = '{2}', Course = '{3}'", student.IDNumber, student.RFID, student.Name, student.Course),
						"IDNumber=" + ListViewStudents.Items[currentStudentIndex].SubItems[1].Text);

					ListViewStudents.Items[currentStudentIndex].SubItems[0].Text = student.Name;
					ListViewStudents.Items[currentStudentIndex].SubItems[1].Text = student.IDNumber.ToString();
					ListViewStudents.Items[currentStudentIndex].SubItems[2].Text = student.RFID.ToString();
					ListViewStudents.Items[currentStudentIndex].SubItems[3].Text = student.Course;
				}

				ToggleFields();
				currentStatus = 0;
			}
			catch (ValidationException ex) {
				MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			catch (Exception ex) {
				Extensions.LogError(ex);
			}
		}
		#endregion

		#region "Context Menu Functions"
		private void editToolStripMenuItem_Click(object sender, EventArgs e) {
			currentStatus = 2;
			currentStudentIndex = ListViewStudents.SelectedItems[0].Index;

			TextBoxStudentName.Text = ListViewStudents.SelectedItems[0].SubItems[0].Text;
			TextBoxIdNum.Text = ListViewStudents.SelectedItems[0].SubItems[1].Text;
			TextBoxRfIdCode.Text = ListViewStudents.SelectedItems[0].SubItems[2].Text;
			TextBoxStudentCourse.Text = ListViewStudents.SelectedItems[0].SubItems[3].Text;

			ToggleFields();
			GroupBoxAddStudent.Text = "Edit Student";
			currentStatus = 2;
		}

		private void deleteToolStripMenuItem_Click(object sender, EventArgs e) {
			if (MessageBox.Show(string.Format("WARNING: You are about to delete the student {0} and all related information. Are you sure you want to continue?", ListViewStudents.SelectedItems[0].SubItems[0].Text), Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {
				try {
					var StudentId = ListViewStudents.SelectedItems[0].SubItems[1].Text;

					// Delete logs of student, then the student itself
					_studentLogHelper.Delete("StudentId=" + StudentId);
					_studentHelper.Delete("IDNumber=" + StudentId);

					ListViewStudents.SelectedItems[0].Remove();
				}
				catch (Exception ex) {
					Extensions.LogError(ex);
				}
			}

		}
		#endregion
	}
}
