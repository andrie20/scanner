using CCSRfidScanner.Entities;
using CCSRfidScanner.SQL;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace CCSRfidScanner {
    public partial class Form1 : Form {
		private readonly SqLiteHelper SqLiteDb = new SqLiteHelper();
        private StudentHelper StudentHelper;
        private SessionHelper SessionHelper;
        private StudentLogHelper StudentLogHelper;

		#region "Current Session"
		Session CurrentSession;
		/* Note for Current Session Status:
		 * 0 : Not accepting
		 * 1 : Log in
		 * 2 : Log out
		 */
		int CurrentSessionStatus = 0;
		#endregion

		#region "Local Functions"
		private void CountSessionLogs() {
			try {
				var sessioncount = StudentLogHelper.Find(string.Format("SessionId={0} AND LogType={1}", CurrentSession.SessionId, CurrentSessionStatus)).Count();

				LabelTotalLogCount.Text = sessioncount.ToString();
			}
			catch {
				LabelTotalLogCount.Text = "-";
			}
		}
		/// <summary>
		/// Finds students by rfid code
		/// </summary>
		/// <param name="rfid"></param>
		/// <returns></returns>
		private long FindStudentByRfid(string rfid) {
			var student = SqLiteDb.ExecuteQuery("SELECT * FROM TStudents WHERE RFID='" + rfid + "'");
			if (student.Rows.Count == 1) {
				LabelStudentName.Text = (string)student.Rows[0].ItemArray[3];
				LabelStudentCourse.Text = (string)student.Rows[0].ItemArray[4];
				return (long)student.Rows[0].ItemArray[0];
			}
			// not found
			return -1;
		}
		private long FindStudentByIdNum(string idNumber) {
			var student = SqLiteDb.ExecuteQuery("SELECT * FROM TStudents WHERE IDNumber='" + idNumber + "'");
			if (student.Rows.Count == 1) {
				LabelStudentName.Text = (string)student.Rows[0].ItemArray[3];
				LabelStudentCourse.Text = (string)student.Rows[0].ItemArray[4];
				return (long)student.Rows[0].ItemArray[0];
			}
			// not found
			return -1;
		}
		private void ChangeSessionStatus(int status) {
			CurrentSessionStatus = status;

			if (status == 0) {
				// nothing
				LabelSessionNotice.Visible = true;

				loginToolStripMenuItem.Checked = false;
				logoutToolStripMenuItem.Checked = false;
				nothingToolStripMenuItem.Checked = true;

				LabelLoginStatus.ForeColor = Color.Gray;
				LabelLogoutStatus.ForeColor = Color.Gray;

				LabelStudentName.Text = "";
				LabelStudentCourse.Text = "";
				LabelTotalLogCount.Text = "";
			}
			else {
				if (status == 1) {
					// log in
					LabelLoginStatus.ForeColor = Color.Black;
					LabelLogoutStatus.ForeColor = Color.Gray;

					loginToolStripMenuItem.Checked = true;
					logoutToolStripMenuItem.Checked = false;
					nothingToolStripMenuItem.Checked = false;

					CountSessionLogs();
				}
				else {
					// log out
					LabelLoginStatus.ForeColor = Color.Gray;
					LabelLogoutStatus.ForeColor = Color.Black;

					loginToolStripMenuItem.Checked = false;
					logoutToolStripMenuItem.Checked = true;
					nothingToolStripMenuItem.Checked = false;

					CountSessionLogs();
				}

				LabelSessionNotice.Visible = false;
			}
		}
		private int WhatStatusIsIt(DateTime now) {
			DateTime LoginEnd = CurrentSession.StartDateTime.AddMinutes(CurrentSession.LogMinutesInterval);
			DateTime LogoutStart = CurrentSession.EndDateTime.AddMinutes(CurrentSession.LogMinutesInterval);

			if ((now < LoginEnd) && (now > CurrentSession.StartDateTime)) {
				return 1;
			}
			else if ((now < CurrentSession.EndDateTime) && (now > LogoutStart)) {
				return 2;
			}
			else {
				return 0;
			}
		}
		private bool ChangeSession(FormSessions formsession) {
			formsession.ShowDialog();

			if(formsession.SelectedSession == null)
				return false;

			CurrentSession = formsession.SelectedSession;

			// Display info
			CountSessionLogs();
			LabelSessionName.Text = CurrentSession.SessionName;
			ChangeSessionStatus(WhatStatusIsIt(DateTime.Now));
			ClockTimer_Tick(null, null);
			ClockTimer.Start();
			LabelAlreadyLoggedIn.Visible = false;
			LabelNotFound.Visible = false;

			return true;
		}
		#endregion

		#region "Form Functions"
		public Form1() {
			InitializeComponent();

			TextBoxRfid.KeyDown += TextBoxRfid_KeyDown;
			FormClosing += Form1_FormClosing;
		}
		private void Form1_Load(object sender, EventArgs e) {
            if (!SqLiteDb.Connect(string.Format("Data Source={0};Version=3;New=False;Compress=True;", Properties.Settings.Default.DatabaseSource))) {
                MessageBox.Show("An error opening database file.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            StudentHelper = new StudentHelper(SqLiteDb);
			SessionHelper = new SessionHelper(SqLiteDb);
			StudentLogHelper = new StudentLogHelper(SqLiteDb);

			Show();
            // WindowState = FormWindowState.Maximized;

            if (!ChangeSession(new FormSessions(SqLiteDb))) {
				Application.Exit();
			}
		}
		private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
			try {
				SqLiteDb.Close();
			}
			catch { } // do nothing on error
		}
		#endregion

		#region "Menu Functions"
		private void ViewSessionsToolStripMenuItem_Click(object sender, EventArgs e) {
			ChangeSession(new FormSessions(SqLiteDb));
		}
		private void ViewStudentsToolStripMenuItem_Click(object sender, EventArgs e) {
			FormStudents formstudents = new FormStudents(SqLiteDb);
			formstudents.ShowDialog();
		}


		#region "Session Status Dropdown Functions"
		private void LoginToolStripMenuItem_Click(object sender, EventArgs e) {
			ChangeSessionStatus(1);
		}
		private void LogoutToolStripMenuItem_Click(object sender, EventArgs e) {
			ChangeSessionStatus(2);
		}
		private void NothingToolStripMenuItem_Click(object sender, EventArgs e) {
			ChangeSessionStatus(0);
		}
		#endregion
		#endregion

		private void ClockTimer_Tick(object sender, EventArgs e) {
			string oldText = LabelTimer.Text;
			LabelTimer.Text = DateTime.Now.ToString("hh:mm tt");

			if(CurrentSession != null && oldText != LabelTimer.Text && automaticToolStripMenuItem.Checked) {
				ChangeSessionStatus(WhatStatusIsIt(DateTime.Now));
			}
		}

		private void TextBoxRfid_KeyDown(object sender, KeyEventArgs e) {
			if (e.KeyCode == Keys.Enter && !string.IsNullOrWhiteSpace(TextBoxRfid.Text)) {
				if (CurrentSessionStatus != 0) {
					try {
						if (CurrentSession == null) {
							MessageBox.Show("WARNING: There is no selected session.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						}

						long studentId = FindStudentByRfid(TextBoxRfid.Text);
						if(studentId == -1) {
							studentId = FindStudentByIdNum(TextBoxRfid.Text);
							if (studentId == -1) {
								LabelNotFound.Visible = true;
								TextBoxRfid.Text = "";
								return;
							}
						}
						else {
							LabelNotFound.Visible = false;
						}
						TextBoxRfid.Text = "";

						// Check if record exists in database
						if (SqLiteDb.ExecuteQuery(string.Format("SELECT * FROM TStudentLogs WHERE StudentId = {0} AND SessionId = {1} AND LogType = {2}",
							studentId, CurrentSession.SessionId, CurrentSessionStatus)).Rows.Count > 0) {
							LabelAlreadyLoggedIn.Visible = true;
							return;
						}

						// if not save to database
						SqLiteDb.ExecuteNonQuery(string.Format("INSERT INTO TStudentLogs (StudentId, SessionId, LogType) VALUES ({0}, {1}, {2})",
							studentId, CurrentSession.SessionId, CurrentSessionStatus));

						LabelNotFound.Visible = false;
						LabelAlreadyLoggedIn.Visible = false;

						CountSessionLogs();
					}
					catch (Exception ex) {
						MessageBox.Show("ERROR: " + ex.Message + " 0x" + ex.HResult.ToString("X2"), Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				}
			}
		}
		private void TextBoxRfid_TextChanged(object sender, EventArgs e) {

		}
	}
}
