﻿using CCSRfidScanner.SQL;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace CCSRfidScanner.Entities {
	public class Student {
		public long? StudentId { get; set; }
		public long IDNumber{ get; set; }
		public long? RFID{ get; set; }
		public string Name { get; set; }
		public string Course { get; set; }
	}

	public class StudentHelper {
		private ISQLDatabase _database;
		private const string _tableName = "TStudents";
		public string[] _fields = new string[] { "StudentId", "IDNumber", "RFID", "Name", "Course" };

		public StudentHelper(ISQLDatabase database) {
			_database = database;
		}

		private Student ParseRow(DataRow row) {
			return row == null ? null : new Student {
				StudentId = row.Field<long>("StudentId"),
				IDNumber = row.Field<long>("IDNumber"),
				RFID = row.Field<long?>("RFID"),
				Name = row.Field<string>("Name"),
				Course = row.Field<string>("Course")
			};
		}
		private IEnumerable<Student> ParseRows(DataRowCollection rows) {
			var students = new List<Student> { };

			foreach (DataRow row in rows) {
				students.Add(ParseRow(row));
			}

			return students;
		}


		public IEnumerable<Student> Find(string query) {
			return ParseRows(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0} ORDER BY Course, Name ASC WHERE {2}", _tableName, string.Join(", ", _fields), query)).Rows);
		}
		public IEnumerable<Student> FindAll() {
			return ParseRows(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0} ORDER BY Course, Name ASC", _tableName, string.Join(", ", _fields))).Rows);
		}
		public Student FindOne(string query) {
			return ParseRow(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0} WHERE {2}", _tableName, string.Join(", ", _fields), query)).Rows.Cast<DataRow>().DefaultIfEmpty(null).FirstOrDefault());
		}

		public int Delete(string query) {
			return _database.ExecuteNonQuery(string.Format("DELETE FROM {0} WHERE {1}", _tableName, query));
		}
		public int Delete(Student student) {
			return _database.ExecuteNonQuery(string.Format("DELETE FROM {0} WHERE {1}={2}", _tableName, _fields[0], student.StudentId));
		}

		public void Insert(Student student) {
			_database.ExecuteNonQuery(string.Format("INSERT INTO {0} ({1}) Values({2}, {3}, '{4}', '{5}')",
				_tableName, string.Join(", ", _fields.Skip(1)),
				student.IDNumber,
				student.RFID == null ? "null" : student.RFID.ToString(),
				student.Name,
				student.Course
			));
		}

		public int Update(string update, string query) {
			return _database.ExecuteNonQuery(string.Format("UPDATE {0} SET {1} WHERE {2}", _tableName, update, query));
		}
	}
}
