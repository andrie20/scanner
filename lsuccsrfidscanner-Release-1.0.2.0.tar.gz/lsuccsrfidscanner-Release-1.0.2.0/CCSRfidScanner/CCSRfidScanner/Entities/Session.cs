﻿using CCSRfidScanner.SQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;

namespace CCSRfidScanner.Entities {
	public class Session {
		public long? SessionId { get; set; }
		public string SessionName { get; set; }
		public DateTime StartDateTime { get; set; }
		public DateTime EndDateTime { get; set; }
		public long LogMinutesInterval { get; set; }
	}
	public class SessionHelper {
		private ISQLDatabase _database;
		private const string _tableName = "TSessions";
		private const string _dateTimeFormat = "MM-dd-yyyy hh:mm tt";
		public string[] _fields = new string[] { "SessionId", "SessionName", "StartDateTime", "EndDateTime", "LogMinutesInterval" };

		private Session ParseRow (DataRow row) {
			return row == null ? null :
				new Session {
					SessionId = row.Field<long>("SessionId"),
					SessionName = row.Field<string>("SessionName"),
					StartDateTime = DateTime.ParseExact(row.Field<string>("StartDateTime"), _dateTimeFormat, CultureInfo.InvariantCulture),
					EndDateTime = DateTime.ParseExact(row.Field<string>("EndDateTime"), _dateTimeFormat, CultureInfo.InvariantCulture),
					LogMinutesInterval = row.Field<long>("LogMinutesInterval")
				};
		}
		private IEnumerable<Session> ParseRows(DataRowCollection rows) {
			var sessions = new List<Session> { };

			foreach (DataRow row in rows) {
				sessions.Add(ParseRow(row));
			}

			return sessions;
		}

		public SessionHelper(ISQLDatabase database) {
			_database = database;
		}


		public IEnumerable<Session> Find(string query) {
			return ParseRows(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0} WHERE {2}", _tableName, string.Join(", ", _fields), query)).Rows).OrderBy(x => x.StartDateTime).Reverse();
		}
		public IEnumerable<Session> FindAll() {
			return ParseRows(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0}", _tableName, string.Join(", ", _fields))).Rows).OrderBy(x => x.StartDateTime).Reverse();
		}
		public Session FindOne(string query) {
			return ParseRow(_database.ExecuteQuery(string.Format("SELECT {1} FROM {0} WHERE {2}", _tableName, string.Join(", ", _fields), query)).Rows.Cast<DataRow>().DefaultIfEmpty(null).FirstOrDefault());
		}

		public int Delete(string query) {
			return _database.ExecuteNonQuery(string.Format("DELETE FROM {0} WHERE {1}", _tableName, query));
		}
		public int Delete(Session session) {
			return _database.ExecuteNonQuery(string.Format("DELETE FROM {0} WHERE {1}={2}", _tableName, _fields[0], session.SessionId));
		}

		public void Insert(Session session) {
			_database.ExecuteNonQuery(string.Format("INSERT INTO {0} ({1}) Values('{2}', '{3}', '{4}', {5})",
				_tableName, string.Join(", ", _fields.Skip(1)),
				session.SessionName,
				session.StartDateTime.ToString(_dateTimeFormat),
				session.EndDateTime.ToString(_dateTimeFormat),
				session.LogMinutesInterval
			));
		}

		public int Update(string update, string query) {
			return _database.ExecuteNonQuery(string.Format("UPDATE {0} SET {1} WHERE {2}", _tableName, update, query));
		}
	}
}
