﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace CCSRfidScanner {
	public static class Extensions {
		public static void LogError(Exception ex) {
			MessageBox.Show(string.Format("ERROR: {0} 0x{1}", ex.Message, ex.HResult.ToString("X2")),
				"CCS RFID Login/Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
			File.AppendAllText("ccsrfidscanner_errorlog.log",
				string.Format("ERROR: {1} 0x{2}{0}{3}{0}{0}", Environment.NewLine, ex.Message, ex.HResult.ToString("X2"), ex.StackTrace));
		}

		public static void ForEach<T>(this IEnumerable<T> ie, Action<T> action) {
			foreach (var i in ie) {
				action(i);
			}
		}
	}
}
